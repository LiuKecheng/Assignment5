package iss.java.mail;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email2014302580251 implements IMailService{
	
	private transient Session session;
	private transient Folder folder;

	@Override
	public void connect() throws MessagingException {
		
		Properties pr=new Properties();
		pr.put("mail.transport.protocol","smtp");
		pr.put("mail.store.protocol","pop3");
		pr.put("mail.smtp.host", "smtp.163.com");
		pr.put("mail.pop3.host","pop3.163.com");
		pr.put("mail.smtp.auth", "true"); 
		
		MyAuthenticator2014302580251 myauth=new MyAuthenticator2014302580251("15927531903@163.com","lympesiafetchpan");
		session=Session.getDefaultInstance(pr, myauth);
		//session.setDebug(true);
		}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		MimeMessage message=new MimeMessage(session);
		message.setSubject(subject);
		message.setContent(content, "text/html;charset=utf-8");
		message.setSentDate(new Date());
		message.setFrom(new InternetAddress("15927531903@163.com"));
		message.addRecipient(MimeMessage.RecipientType.TO,
			      new InternetAddress(recipient));
		message.saveChanges();
		Transport.send(message);
	}

	@Override
	public boolean listen() throws MessagingException {
		
		Store store=session.getStore();
		store.connect("260036989@163.com","lympesiafetchpan" );
		folder=store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		
		if(folder.getUnreadMessageCount()!=0)
			return true;
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		System.out.println("The subject is:"+subject);
		System.out.println("The content is:");  
		String content=folder.getMessage(folder.getMessageCount()).getContent().toString();
		folder.close(true);
		return content;
	}

}
