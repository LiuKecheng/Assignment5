package iss.java.mail;

import javax.mail.PasswordAuthentication;

public class MyAuthenticator2014302580251  extends javax.mail.Authenticator {
	 private String strUser;
	    private String strPwd;
	    public MyAuthenticator2014302580251(String user, String password) {
	      this.strUser = user;
	      this.strPwd = password;
	    }

	    protected PasswordAuthentication getPasswordAuthentication() {
	      return new PasswordAuthentication(strUser, strPwd);
	    }

	

}
